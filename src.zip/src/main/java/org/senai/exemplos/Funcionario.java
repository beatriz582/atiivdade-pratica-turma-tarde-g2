package org.senai.exemplos;

public abstract class Funcionario {
    protected String nome;
    protected double salario;

    public Funcionario(String nome, double salario) {
        this.nome = nome;
        this.salario = salario;
    }

    public double getSalario() {
        return salario;
    }

    public double calcularBonus(double percentual) {
        return salario + (salario * percentual);
    }

    public void mostrarDados() {
        System.out.println("Nome: " + nome + " | Salário: " + salario);
    }
}

public class Gerente extends Funcionario {
    private double bonusExtra;

    public Gerente(String nome, double salario, double bonusExtra) {
        super(nome, salario);
        this.bonusExtra = bonusExtra;
    }

    @Override
    public double calcularBonus(double percentual) {
        return getSalario() + (getSalario() * percentual) + bonusExtra;
    }

    public void mostrarBonus() {
        System.out.println("Bônus extra: " + bonusExtra);
    }
}
