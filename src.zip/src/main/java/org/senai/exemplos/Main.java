package org.senai.exemplos;

public class Main {
    public static void main(String[] args) {
        Gerente func1 = new Gerente("Priscila", 3000.0, 0.0);
        func1.mostrarDados();

        Gerente func2 = new Gerente("Keyla", 5000.0, 500.0);
        func2.mostrarDados();
        func2.mostrarBonus();
    }
}
